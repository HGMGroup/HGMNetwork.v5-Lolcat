module Lolcat
  VERSION = "100.0.0"
end
